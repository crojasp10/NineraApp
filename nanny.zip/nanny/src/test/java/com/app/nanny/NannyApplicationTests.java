package com.app.nanny;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NannyApplicationTests {

	@Test
	void contextLoads() {
	}

}
