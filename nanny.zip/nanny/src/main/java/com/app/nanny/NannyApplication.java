package com.app.nanny;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NannyApplication {

	public static void main(String[] args) {
		SpringApplication.run(NannyApplication.class, args);
	}

}
